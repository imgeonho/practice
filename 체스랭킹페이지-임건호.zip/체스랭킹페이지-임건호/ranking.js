const players = [
    { name:"임건호", rating:1850, win:25, lose:5 },
    { name:"카리나", rating:1780, win:22, lose:8 },
    { name:"리 신", rating:1720, win:20, lose:10 },
    { name:"유재석", rating:1680, win:18, lose:9 },
    { name:"싸 이", rating:1650, win:16, lose:10 },
    { name:"체스고수", rating:1620, win:15, lose:11 },
    { name:"초보에요", rating:1590, win:14, lose:12 },
    { name:"밥먹고체스만함", rating:1550, win:13, lose:13 },
    { name:"젠슨 황", rating:1500, win:10, lose:14 },
    { name:"장원영", rating:1480, win:9, lose:15 }
];

/* =========================
   프로필 이미지 (외부 API)
========================= */
function getAvatar(name){
    return `https://api.dicebear.com/7.x/adventurer/svg?seed=${name}`;
}

/* =========================
   랭킹 알고리즘
========================= */
function calcScore(p){
    return p.rating + (p.win * 10) - (p.lose * 5);
}

/* =========================
   메인 렌더링 + 데이터 처리
========================= */
function render(keyword=""){

    // 점수 계산
    players.forEach(p=>{
        p.score = calcScore(p);
    });

    // 정렬 (알고리즘)
    players.sort((a,b)=>b.score-a.score);

    // 순위 부여
    players.forEach((p,i)=>{
        p.rank = i+1;
    });

    // 검색 필터
    const filtered =
        players.filter(p=>p.name.includes(keyword));

    const tbody =
        document.getElementById("rankingBody");

    tbody.innerHTML="";

    filtered.forEach(p=>{

        const winRate =
            (p.win/(p.win+p.lose))*100;

        let badge =
            p.rank===1?"gold":
            p.rank===2?"silver":
            p.rank===3?"bronze":"";

        tbody.innerHTML += `
        <tr>
            <td>
                <span class="rank-badge ${badge}">
                    ${p.rank}
                </span>
            </td>
            <td>${p.name}</td>
            <td>${p.rating}</td>
            <td>${p.win}</td>
            <td>${p.lose}</td>
            <td>${winRate.toFixed(1)}%</td>
            <td>${p.score}</td>
        </tr>`;
    });

    // 통계
    document.getElementById("playerCount")
        .textContent = players.length;

    document.getElementById("topRating")
        .textContent = players[0].rating;

    const avg =
        players.reduce((a,b)=>a+b.rating,0)
        /players.length;

    document.getElementById("avgRating")
        .textContent = Math.round(avg);

    updateTop3();
}

/* =========================
   TOP3 업데이트
========================= */
function updateTop3(){

    const top = players.slice(0,3);
    const ids = ["first","second","third"];

    top.forEach((p,i)=>{

        document.getElementById(ids[i]+"Name")
            .textContent = p.name;

        document.getElementById(ids[i]+"Rating")
            .textContent = "⭐ " + p.rating;

        document.getElementById(ids[i]+"Img")
            .src = getAvatar(p.name);
    });
}

/* 검색 */
document
.getElementById("searchInput")
.addEventListener("input",(e)=>{
    render(e.target.value);
});

/* 초기 실행 */
render();