async function sendMessage() {
 const input = document.getElementById("userInput");
 const chatBox = document.getElementById("chatBox");
 const message = input.value.trim();
 if (!message) return;
appendMessage("user", message);
 input.value = "";
const loadingEl = appendMessage("ai", "입력중...");
 try {
  const response = await
fetch("http://127.0.0.1:5000/chat", {
   method: "POST",
   headers: { "Content-Type": "application/json" },
   body: JSON.stringify({ message: message })
  });
  const data = await response.json();
  loadingEl.remove();
  appendMessage("ai", data.reply || "오류가발생했습니다.");
 } catch (error) {
  loadingEl.remove();
  appendMessage("ai", "서버에연결할수없습니다. server.py가실행중인지확인하세요.");
 }
 chatBox.scrollTop = chatBox.scrollHeight;
}
function appendMessage(role, text) {
 const chatBox = document.getElementById("chatBox");
 const div = document.createElement("div");
 div.className = `message ${role}`;
 div.textContent = text;
 chatBox.appendChild(div);
 chatBox.scrollTop = chatBox.scrollHeight;
 return div;
}
