const API_KEY = "d03d92e61f475b63928f3bafe9ef050d";

const foods = [
    { name: "김치찌개 🍲", type: "hot" },
    { name: "된장찌개 🥘", type: "hot" },
    { name: "라면 🍜", type: "hot" },
    { name: "국밥 🥣", type: "hot" },

    { name: "냉면 🧊", type: "cold" },
    { name: "샐러드 🥗", type: "cold" },

    { name: "초밥 🍣", type: "neutral" },
    { name: "햄버거 🍔", type: "neutral" },
    { name: "비빔밥 🍚", type: "neutral" }
];

async function getWeather(city) {
    try {
        const res = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
        );

        const data = await res.json();
        return data.main.temp;

    } catch (err) {
        alert("날씨 정보를 불러올 수 없습니다");
        return 20;
    }
}

function getFoodByTemp(temp) {
    if (temp >= 25) return foods.filter(f => f.type === "cold");
    if (temp <= 10) return foods.filter(f => f.type === "hot");
    return foods.filter(f => f.type === "neutral");
}

async function spin() {

    const city = document.getElementById("city").value.trim();
    const result = document.getElementById("result");

    if (!city) {
        alert("지역을 입력해주세요!");
        return;
    }

    result.innerText = "🎡 룰렛 돌리는 중...";

    const temp = await getWeather(city);
    const list = getFoodByTemp(temp);

    setTimeout(() => {
        const pick = list[Math.floor(Math.random() * list.length)];
        result.innerText = `🍱 ${city} 룰렛 결과: ${pick.name} (${temp}°C)`;
    }, 1200);
}

function goHome() {
    location.href = "index.html";
}
function setCity(city) {
    document.getElementById("city").value = city;
}

function saveHistory(text) {
    let history = JSON.parse(localStorage.getItem("foodHistory")) || [];

    history.unshift(text);

    if (history.length > 5) {
        history = history.slice(0, 5);
    }

    localStorage.setItem("foodHistory", JSON.stringify(history));

    console.log("저장됨:", history);
}