const firebaseConfig = {
  apiKey: "AIzaSyCwV_oj-7_UhygU1jRzMm3j_xlF2UiCg2U",
  authDomain: "web-bigda.firebaseapp.com",
  databaseURL: "https://web-bigda-default-rtdb.firebaseio.com",
  projectId: "web-bigda",
  storageBucket: "web-bigda.firebasestorage.app",
  messagingSenderId: "830709803467",
  appId: "1:830709803467:web:b9ee7bd686c68ecfbfae4e",
  measurementId: "G-02LRXE3PPL"
};

firebase.initializeApp(firebaseConfig);
