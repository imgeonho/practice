const auth = firebase.auth();

auth.onAuthStateChanged(user => {
  if (user) {
    document.getElementById('welcome-msg').textContent =
      user.email + "님, 환영합니다!";

    loadHistory();

  } else {
    alert('로그인이 필요합니다.');
    location.href = 'login.html';
  }
});

function logout() {
  auth.signOut().then(() => {
    alert('로그아웃 되었습니다.');
    location.href = 'login.html';
  });
}

function goHome() {
  location.href = "index.html";
}

function loadHistory() {
    let history = JSON.parse(localStorage.getItem("foodHistory")) || [];

    console.log("불러온 기록:", history);

    const box = document.getElementById("historyList");

    if (!history || history.length === 0) {
        box.innerHTML = "<p>아직 추천 기록이 없습니다.</p>";
        return;
    }

    box.innerHTML = history.map(item =>
        `<div class="history-item">🍱 ${item}</div>`
    ).join("");
}