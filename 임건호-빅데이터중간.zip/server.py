from flask import Flask, request, jsonify
from flask_cors import CORS
from google import genai
from dotenv import load_dotenv
import os
load_dotenv()
app = Flask(__name__)
CORS(app)
api_key = AQ.Ab8RN6LAyPPUY2WIT6w5W0c2B8bjBtHnStyK7qnHfPexziuldA
if not api_key:
  raise ValueError("GEMINI_API_KEY가설정되지않았습니다. .env 파일을확인하세요.")
client = genai.Client(api_key=api_key)
@app.route("/chat", methods=["POST"])
def chat():
  data = request.get_json()
